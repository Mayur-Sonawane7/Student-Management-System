package com.admin.controller;

import static org.junit.Assert.assertNotNull;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.forwardedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import javax.servlet.ServletContext;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockServletContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:springmvc-servlet.xml"})
@WebAppConfiguration
public class BaseTest {

	@Autowired
	private WebApplicationContext webapplicationContext;
	
	protected MockMvc mockMvc;
	
	// this method initializes mockMvc
	@org.junit.Before
	public void setup() throws Exception {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.webapplicationContext).build();
	}
	
	@Test
	public void test() {
		ServletContext servletContext= webapplicationContext.getServletContext();
		
		Assert.assertNotNull(servletContext); //servletContext should not be null
		Assert.assertTrue(servletContext instanceof MockServletContext); //MockServletContext should be instance of servletContext
		Assert.assertNotNull(webapplicationContext.getBean("controller")); // admin controller bean should not be null
		
	}
	
}
