package com.admin.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.forwardedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.Test;
import org.springframework.test.web.servlet.MockMvc;

public class AdminControllerTest extends BaseTest {

	//MockMvc mockMvcTemp = super.mockMvc;
	
	BaseTest baseTest = new BaseTest();
	
	
    @Test
	public void homeTest() throws Exception {
		baseTest.setup();
		super.mockMvc.perform(get("/adminlogin")).andExpect(status().isOk())
		.andExpect(view().name("adminlogin"))
		.andExpect(forwardedUrl("/WEB-INF/view/adminlogin.jsp"));
		
	}
	
//	@Test
//	public void handleFormTest() throws Exception {
//		
//		super.mockMvc.perform(post("/adminlogin")).andExpect(status().isOk())
//		.andExpect(view().name("adminlogin"))
//		.andExpect(forwardedUrl("/WEB-INF/view/adminlogin.jsp"));
//		
//	}
}
