package com.admin.dao;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.admin.DaoImpl.DaoImpl;
import com.admin.Model.User;
import com.admin.controller.BaseTest;

public class AdminDaoTest extends BaseTest {

	@Autowired
	private DaoImpl daoImpl;
	
	@Test
	public void getAdminTest() {
		
		User user = new User();
		
		user.setUsername("test");
		user.setPassword("test123");

		List<Object[]> userlist = daoImpl.getAdmin(user);
		
	//	User userExp = new User("test","test123");
		
		Assert.assertNotNull(userlist);
	}
	
}
