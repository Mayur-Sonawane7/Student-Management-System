package com.student.dao;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.admin.DaoImpl.DaoImpl;
import com.admin.Model.User;
import com.admin.controller.BaseTest;
import com.student.DaoImpl.StudentDao;
import com.student.Model.StudForm;

public class StudentDaoTest extends BaseTest{

	@Autowired
	StudentDao studentDao;
	
	@Test
	public void addStudentTest1() {
		
		StudForm form = new StudForm();
		form.setStudentId(21);
		form.setStudentName("Mahesh Patil");
		form.setDepartment("Mechanical");
		form.setAddupdate("add");
		
		
		int student = studentDao.addStudent(form, 100);
		
		Assert.assertEquals(0, student);
		
	}
	
	@Test
	public void addStudentTest2() {
		
		StudForm form = new StudForm();
		form.setStudentId(27);
		form.setStudentName("Shubham Deshpande");
		form.setDepartment("Civil");
		form.setAddupdate("add");
		
		int student = studentDao.addStudent(form, 100);
		
		Assert.assertEquals(1, student);
		
	}
	
	@Test
	public void getAllStudentTest() {
		List<Object[]> studList = studentDao.getAllStudent();
		Assert.assertNotNull(studList);
	}
	
	@Test
	public void deleteStudentTest() {
		
		StudForm studForm = new StudForm(13,"Mayur Sonawane","Mechanical","add"); 
		
		int deleteStudent = studentDao.deleteStudent(studForm);
		
		Assert.assertEquals(1, deleteStudent);
	}
	
	@Test
	public void updateStudentTest() {
		StudForm studForm = new StudForm(10,"Omkar Sonawane","Mechanical","add");
		int updateStudent = studentDao.updateStudent(studForm);
		Assert.assertEquals(1, updateStudent);
	}
	
	
//	@Autowired
//	private DaoImpl daoImpl;
//	
//	@Test
//	public void getAdminTest() {
//		
//		User user = new User();
//		
//		user.setUsername("test");
//		user.setPassword("test123");
//
//		List<Object[]> userlist = daoImpl.getAdmin(user);
//		
//		User userExp = new User("test","test123");
//		
//		Assert.assertEquals(userExp.toString(),userlist.toString());
//	}
	
	
	
}
