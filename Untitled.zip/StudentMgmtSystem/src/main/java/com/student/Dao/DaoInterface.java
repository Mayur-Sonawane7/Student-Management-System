package com.student.Dao;

import java.util.List;

import com.student.Model.StudForm;

public interface DaoInterface {

	public int addStudent(StudForm studForm, int adminId) ;

	public List<Object[]> getAllStudent();

	public int updateStudent(StudForm studForm);

	public int deleteStudent(StudForm studForm) ;
		
}
