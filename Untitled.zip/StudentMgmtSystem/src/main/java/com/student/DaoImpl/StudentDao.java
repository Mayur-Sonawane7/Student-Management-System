package com.student.DaoImpl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.NativeQuery;
import org.springframework.stereotype.Repository;

import com.student.Dao.DaoInterface;
import com.student.Model.StudForm;
import com.student.Model.Student;

@Repository
public class StudentDao implements DaoInterface {

	SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();

	public int addStudent(StudForm studForm, int adminId) {

//		if(studForm.getStudentName()==null || studForm.getDepartment()==null || studForm.getStudentName()=="") {
//			
//			return 2;
//		}
		
		Session session = null;  
		Transaction tx = null;  		

		try {  
			session = sessionFactory.openSession();  
			tx = session.beginTransaction();  
			System.out.println("insert into student values("+studForm.getStudentId() +",'"+studForm.getStudentName() +"', '"+studForm.getDepartment() +"', "+adminId +");");

			NativeQuery nq = session.createSQLQuery("insert into student values("+studForm.getStudentId() +",'"+studForm.getStudentName() +"', '"+studForm.getDepartment() +"', "+adminId +");");
			nq.executeUpdate();	
			tx.commit();  
			return 1;
		}

		catch (Exception e) {  
			e.printStackTrace();  
			tx.rollback();  
			return 0;
		}  

		finally {
			session.close();
		} 

//		return 1;
	}

	public List<Object[]> getAllStudent(){

		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();

		NativeQuery nq = session.createSQLQuery("select * from student;");
		List<Object[]>  StudentList= nq.list();

		return StudentList;
	}

	public int updateStudent(StudForm studForm) {

		Session session = null;  
		Transaction tx = null;  		

		try {  
			session = sessionFactory.openSession();  
			tx = session.beginTransaction();  
			System.out.println("update student set student_name='"+studForm.getStudentName() +"', department='"+ studForm.getDepartment()+"' where student_id="+studForm.getStudentId()+";");

			NativeQuery nq = session.createSQLQuery("update student set student_name='"+studForm.getStudentName() +"', department='"+ studForm.getDepartment()+"' where student_id="+studForm.getStudentId()+";");
			nq.executeUpdate();	
			tx.commit();  
			return 1;
		}

		catch (Exception e) {  
			e.printStackTrace();  
			tx.rollback();
			return 0;
		}  

		finally {
			session.close();
		} 

	}

	public int deleteStudent(StudForm studForm) {

		Session session = null;  
		Transaction tx = null;  
		
		try {  
			session = sessionFactory.openSession();  
			tx = session.beginTransaction();  
			 NativeQuery query = session.createSQLQuery("delete from student where student_id ="+studForm.getStudentId()+";");
			int executeUpdate = query.executeUpdate();
			tx.commit();
			return 1;
		}
		
		catch (Exception e) {  
			e.printStackTrace();  
			tx.rollback();  
			return 0;
		}  

		finally {
			session.close();
		} 
		
	}

}
