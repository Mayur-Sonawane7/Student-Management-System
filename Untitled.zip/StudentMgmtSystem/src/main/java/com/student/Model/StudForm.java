package com.student.Model;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

public class StudForm {

	@Positive(message = "Student Id should be positive.")
	private int studentId;
	@NotNull(message = "Student name must not be null.")
	private String studentName;
	@NotEmpty(message = "Department must not be empty.")
	private String department;
	
	private String addupdate;
	
	public StudForm() {
		
	}
	
	public StudForm(int studentId, String studentName, String department, String addupdate) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.department = department;
		this.addupdate = addupdate;
	}


	public int getStudentId() {
		return studentId;
	}


	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}


	public String getStudentName() {
		return studentName;
	}


	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}


	public String getDepartment() {
		return department;
	}


	public void setDepartment(String department) {
		this.department = department;
	}


	public String getAddupdate() {
		return addupdate;
	}


	public void setAddupdate(String addupdate) {
		this.addupdate = addupdate;
	}


	@Override
	public String toString() {
		return "StudForm [studentId=" + studentId + ", studentName=" + studentName + ", department=" + department
				+ ", addupdate=" + addupdate + "]";
	}

	
}
