package com.student.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Student {
	
	@Id
	@Column(name="student_id")
	private int student_id;
	@Column(name="student_name")
	private String student_name;
	@Column(name="department")
	private String department;
	
	private int adminId;
	
	public Student() {
		super();
	}

	public Student(int student_id, String student_name, String department, int adminId) {
		super();
		this.student_id = student_id;
		this.student_name = student_name;
		this.department = department;
		this.adminId = adminId;
	}

	public int getStudent_id() {
		return student_id;
	}

	public void setStudent_id(int student_id) {
		this.student_id = student_id;
	}

	public String getStudent_name() {
		return student_name;
	}

	public void setStudent_name(String student_name) {
		this.student_name = student_name;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public int getAdminId() {
		return adminId;
	}

	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}

	@Override
	public String toString() {
		return "Student [student_id=" + student_id + ", student_name=" + student_name + ", department=" + department
				+ ", adminId=" + adminId + "]";
	}

}
