package com.student.controller;

import java.util.List;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.student.DaoImpl.StudentDao;
import com.student.Model.StudForm;
import com.student.Model.Student;
import com.admin.controller.*;

@Controller
public class StudentController {

	@Autowired
	public com.admin.controller.Controller controller;

	@Autowired
	public StudentDao dao;
	
	
	@RequestMapping("/studentform3")
	public String addStudent(Model model) {

		model.addAttribute("addOrupdate","add");
		
		return "studentform3";
	}
	
	@RequestMapping("/update")
	public String updateStudent(Model model) {

		model.addAttribute("addOrupdate","update");
		
		return "studentform3";
	}
	
	@RequestMapping("/deleteStud")
	public String deleteStudent() {
		
		return "deleteStudent";
	}

	@RequestMapping("/studList")
	public String getAllStudent( Model model) {
		List<Object[]> studList = dao.getAllStudent();
		model.addAttribute("studList",studList);
		System.out.println("returning getstudent.jsp");
		return "getstudent";
	}
	
	@RequestMapping("/delete") 
	public String deleteStudent(@ModelAttribute StudForm studForm, Model model) {
		
		int temp = dao.deleteStudent(studForm);
		
		if(studForm.getStudentId()<=0) {
			model.addAttribute("msg","All Fields are required!!");
		}
		
		else if(temp==1){
			model.addAttribute("msg","Student data deleted successfully!!");
		}
		
		else {
			model.addAttribute("msg","Entered Id Does Not Exist in Database. Please Enter Valid Id.");
		}
		
		return "deleteStudent";
	}
	
	
	@RequestMapping(path="/studentform3", method=RequestMethod.POST)
	public void addupdateStudent(@ModelAttribute("stud") StudForm studForm, Model model, BindingResult br) {

		System.out.println(studForm);
		System.out.println(studForm.getAddupdate());
		
		if(studForm.getStudentName()==null || studForm.getDepartment()==null || studForm.getStudentName()=="" || studForm.getStudentId()<=0) {
			model.addAttribute("msg","All Fields are required!!");
		}	
		
		else if(studForm.getAddupdate().equals("add")) {
			int adminId= controller.adminId;
			System.out.println("admin Id from controller : - "+adminId);
			int temp = dao.addStudent(studForm, adminId);
			
			if(br.hasErrors()) {
				model.addAttribute("msg","Enter Valid Student Data.");
			}
			
			else if(temp==0){
				model.addAttribute("msg","Entered Id Already Exist in Database. Please Enter Valid Id.");
			}
			 
			else {
				model.addAttribute("msg","Student Data Saved Successfully!!");
			}
		}
		
		else {
			dao.updateStudent(studForm);	
			model.addAttribute("msg","Student Data Updated Successfully!!");
		}

	}

//	if(studForm.getAddupdate().equals("add")) {
//		int adminId= controller.adminId;
//		System.out.println("admin Id from controller : - "+adminId);
//		int temp = dao.addStudent(studForm, adminId);
//		
//		if(br.hasErrors()) {
//			model.addAttribute("msg","Enter Valid Student Data.");
//		}
//		
//		else if(temp==0){
//			model.addAttribute("msg","Entered Id Already Exist in Database. Please Enter Valid Id.");
//		}
//		 
//		else {
//			model.addAttribute("msg","Student Data Saved Successfully!!");
//		}
//	}
//	
//	else {
//		dao.updateStudent(studForm);	
//		model.addAttribute("msg","Student Data Updated Successfully!!");
//	}
	
}
