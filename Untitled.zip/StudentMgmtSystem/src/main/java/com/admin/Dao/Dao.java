package com.admin.Dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.NativeQuery;

import com.admin.Model.User;

public interface Dao {
	
	public List<Object[]> getAdmin(User user);

}
