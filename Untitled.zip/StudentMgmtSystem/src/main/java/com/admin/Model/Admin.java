package com.admin.Model;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Entity
public class Admin {

	@Id
	private int admin_id;
	private String username;
	private String college;
	private String userpassword;
	
	
	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Admin(int admin_id, String username, String college, String userpassword) {
		super();
		this.admin_id = admin_id;
		this.username = username;
		this.college = college;
		this.userpassword = userpassword;
	}

	public int getAdmin_id() {
		return admin_id;
	}

	public void setAdmin_id(int admin_id) {
		this.admin_id = admin_id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getCollege() {
		return college;
	}

	public void setCollege(String college) {
		this.college = college;
	}

	public String getuserPassword() {
		return userpassword;
	}

	public void setuserPassword(String userpassword) {
		this.userpassword = userpassword;
	}

	@Override
	public String toString() {
		return "Admin [admin_id=" + admin_id + ", username=" + username + ", college=" + college + ", password="
				+ userpassword + "]";
	}
	
}
