package com.admin.controller;

import java.util.Arrays;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.admin.DaoImpl.DaoImpl;
import com.admin.Model.User;
import com.student.DaoImpl.StudentDao;

@org.springframework.stereotype.Controller
public class Controller {

	public int adminId;
	
	@Autowired
	public DaoImpl daoImpl;
	
	@Autowired
	public StudentDao dao;
	
	@RequestMapping("/adminlogin")
	public String home() {

		return "adminlogin";
	}

	@RequestMapping(path = "/adminlogin", method = RequestMethod.POST)
	public String handleForm(@ModelAttribute User user, Model model) {
		
		System.out.println("User ---> "+user);
		
		if(user.getUsername()=="" || user.getPassword()=="") {
			model.addAttribute("nullmsg", "*Please Enter Username & Password.");
			return "adminlogin"; 
		}
		
		else {
			List<Object[]> userlist  = daoImpl.getAdmin(user);
			System.out.println("Admin data from html form : "+user);
			
			if(userlist.isEmpty()) {
				System.out.println("password & username NOT matched!!");
				model.addAttribute("msg", "Incorrect Username or Password. Please Enter correct Username & Password.");
				return "adminlogin"; 
			}
			
			else {
				System.out.println("password & username matched!!");
				for (Object[] objects : userlist) {
					adminId=(Integer) objects[0];
				}
				List<Object[]> studList = dao.getAllStudent();
				model.addAttribute("studList",studList);
				System.out.println("returning getstudent.jsp");
				return "getstudent";
			}
		}
		
	}
}
