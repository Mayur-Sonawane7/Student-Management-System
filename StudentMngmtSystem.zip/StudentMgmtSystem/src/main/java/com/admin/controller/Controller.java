package com.admin.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.admin.DaoImpl.DaoImpl;
import com.admin.Model.User;
import com.student.DaoImpl.StudentDao;

@org.springframework.stereotype.Controller
public class Controller {

	public int adminId;
	
	@Autowired
	public DaoImpl daoImpl;
	
	@Autowired
	public StudentDao dao;
	
	@RequestMapping("/adminlogin")
	public String home() {

		return "adminlogin";
	}

	@RequestMapping(path = "/adminlogin", method = RequestMethod.POST)
	public String handleForm(@ModelAttribute User user, Model model) {
		
		List<Object[]> userlist  = daoImpl.getAdmin(user);
		
		System.out.println("Admin data from html form : "+user);
		
		if(userlist.isEmpty()) {
			System.out.println("password & username NOT matched!!");
			model.addAttribute("msg", "Incorrect Username or Password. Please Enter correct Username & Password.");
			return "adminlogin"; //adminlogin
		}
		
		else {
			System.out.println("password & username matched!!");
			for (Object[] objects : userlist) {
				adminId=(Integer) objects[0];
			}
			List<Object[]> studList = dao.getAllStudent();
//			for (Object[] objects : studList) {
//				System.out.println(objects[0]+", "+objects[1]+", "+objects[2]+", "+objects[3]);
//			}
			model.addAttribute("studList",studList);
			System.out.println("returning getstudent.jsp");
			return "getstudent";
		}
	}

//	@RequestMapping(path="/processform", method= RequestMethod.POST )
//	public String handleForm2(@RequestParam("username") String username,
//							@RequestParam("password") String password,
//							Model model)
//	{
//		/* model.addAttribute("email", password); */
//		
//		return "success";
//	}

	
//	List<Object[]> userlist = nq.list();
//
//	for (Object[] user1 : userlist) {
//		System.out.println(user1[1]+" "+user1[3]);
//		//if (user.getUsername() == user1[1] & user.getPassword() == user1[3]) {
//		if (user.getUsername().equals(user1[1])  & user.getPassword().equals(user1[3]) ) {	
//			System.out.println("password & username matched!!");
//			break;
//		}
//		else {
//			System.out.println("password & username NOT matched!!");
//			
//		}
//	}
}
