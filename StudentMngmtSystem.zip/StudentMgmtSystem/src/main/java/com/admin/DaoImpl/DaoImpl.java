package com.admin.DaoImpl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.NativeQuery;
import org.springframework.stereotype.Repository;

import com.admin.Dao.Dao;
import com.admin.Model.User;

@Repository
public class DaoImpl implements Dao {

	int adminId;
	
	public List<Object[]> getAdmin(User user) {
		
		SessionFactory sf = new Configuration().configure().buildSessionFactory();

		Session session = sf.openSession();
		
		NativeQuery nq = session.createSQLQuery("select * from admin where username='" + user.getUsername()
				+ "' and userpassword='" + user.getPassword() + "';");

//		List<Object[]> adminlist = nq.list();
//		
//		for (Object[] objects : adminlist) {
//			adminId=(Integer) objects[0];
//		}
		
		return nq.list();
	}

}
