package com.student.Model;

import javax.validation.constraints.NotNull;

public class StudForm {


	int studentId;
	String studentName;
	String department;
	
	String addupdate;
	
	public StudForm() {
		
	}
	
	
	public StudForm(int studentId, String studentName, String department, String addupdate) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.department = department;
		this.addupdate = addupdate;
	}


	public int getStudentId() {
		return studentId;
	}


	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}


	public String getStudentName() {
		return studentName;
	}


	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}


	public String getDepartment() {
		return department;
	}


	public void setDepartment(String department) {
		this.department = department;
	}


	public String getAddupdate() {
		return addupdate;
	}


	public void setAddupdate(String addupdate) {
		this.addupdate = addupdate;
	}


	@Override
	public String toString() {
		return "StudForm [studentId=" + studentId + ", studentName=" + studentName + ", department=" + department
				+ ", addupdate=" + addupdate + "]";
	}

	
}
