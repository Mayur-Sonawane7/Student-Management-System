package com.student.controller;

import java.util.List;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.student.DaoImpl.StudentDao;
import com.student.Model.StudForm;
import com.student.Model.Student;
import com.admin.controller.*;

@Controller
public class StudentController {

	@Autowired
	public com.admin.controller.Controller controller;

	@Autowired
	public StudentDao dao;
	
	
	@RequestMapping("/studentform3")
	public String addStudent(Model model) {

		model.addAttribute("addOrupdate","add");
		
		return "studentform3";
	}
	
	@RequestMapping("/update")
	public String updateStudent(Model model) {

		model.addAttribute("addOrupdate","update");
		
		return "studentform3";
	}
	
	@RequestMapping("/deleteStud")
	public String deleteStudent() {
		
		return "deleteStudent";
	}

	@RequestMapping("/studList")
	public String getAllStudent( Model model) {
//		for (Object[] objects : userlist) {
//			adminId=(Integer) objects[0];
//		}
		List<Object[]> studList = dao.getAllStudent();
//		for (Object[] objects : studList) {
//			System.out.println(objects[0]+", "+objects[1]+", "+objects[2]+", "+objects[3]);
//		}
		model.addAttribute("studList",studList);
		System.out.println("returning getstudent.jsp");
		return "getstudent";
	}
	
//	@RequestMapping(path="/studentform3", method=RequestMethod.POST)
//	public void addStudent(@ModelAttribute StudForm studForm, Model model) {
//
//		System.out.println(studForm);
//
//		int adminId= controller.adminId;
//		System.out.println("admin Id from controller : - "+adminId);
//		int temp = dao.addStudent(studForm, adminId);
//		if(temp==0){
//			model.addAttribute("msg","Entered Id Already Exist in Database. Please Enter Valid Id.");
//		}
//		
//	}
	
//	@RequestMapping(path="/update", method=RequestMethod.POST)
//	public String updateStudent(@ModelAttribute StudForm studForm, Model model) {
//
//		System.out.println(studForm);
//
//		dao.updateStudent(studForm);	
//		
//		return "studentform3";
//	}
	
	@RequestMapping("/delete") //, method=RequestMethod.POST
	public String deleteStudent(@ModelAttribute StudForm studForm, Model model) {
		
		int temp = dao.deleteStudent(studForm);
		
		if(temp==1){
			model.addAttribute("msg","Student data deleted successfully!!");
		}
		
		else {
			model.addAttribute("msg","Entered Id Does Not Exist in Database. Please Enter Valid Id.");
		}
		
		return "deleteStudent";
	}
	
	
	@RequestMapping(path="/studentform3", method=RequestMethod.POST)
	public void addupdateStudent(@ModelAttribute StudForm studForm, Model model) {

		System.out.println("Student ID :---"+studForm.getStudentId());
		
		System.out.println(studForm);
		
		System.out.println(studForm.getAddupdate());
		
		if(studForm.getAddupdate().equals("add")) {
			int adminId= controller.adminId;
			System.out.println("admin Id from controller : - "+adminId);
			int temp = dao.addStudent(studForm, adminId);
			
			if(temp==0){
				model.addAttribute("msg","Entered Id Already Exist in Database. Please Enter Valid Id.");
			}
			else {
				model.addAttribute("msg","Student Data Saved Successfully!!");
			}
		}
		
		else {
			dao.updateStudent(studForm);	
			model.addAttribute("msg","Student Data Updated Successfully!!");
		}

//		int adminId= controller.adminId;
//		System.out.println("admin Id from controller : - "+adminId);
//		int temp = dao.addStudent(studForm, adminId);
//		if(temp==0){
//			model.addAttribute("msg","Entered Id Already Exist in Database. Please Enter Valid Id.");
//		}
		
	}
	
	
	//--------------------------------------------------------------------------------------
//	model.addAttribute("Id","- Student ID : ");
//	model.addAttribute("Name", "- Student Name : ");
//	model.addAttribute("Dept","- Department : ");
//	
//	model.addAttribute("studentId", studForm.getStudentId());
//	model.addAttribute("studentName", studForm.getStudentName());
//	model.addAttribute("department", studForm.getDepartment());
	
	
	
//	@GetMapping("/getstudent")
//	public void getAllStudent(Model model) {
//		System.out.println("/**********////***********");
//		List<Object[]> studList = dao.getAllStudent();
//		
//		for (Object[] objects : studList) {
//			System.out.println(objects[0]+", "+objects[1]+", "+objects[2]+", "+objects[3]);
//		}
////		for (Student student: studList) {
////			System.out.println(student);
////		}
//		
//		model.addAttribute("studList",studList);
//		
//	}
	
//	@RequestMapping(path="/studentform3", method=RequestMethod.POST)
//	public void addStudent(@ModelAttribute StudForm studForm) {
//
//		System.out.println(studForm);
//
//		int adminId= controller.adminId;
//		dao.addStudent(studForm, adminId);
//	
//	}

}
